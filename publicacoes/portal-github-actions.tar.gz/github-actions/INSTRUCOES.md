# Publicação do Portal via GitHub Actions

1. Copie `.github/workflows/publicar-portal.yml` para o repositório `avec-franquias/Dashboard-comercial-avec`.
2. Crie a pasta `publicacoes` na raiz do repositório.
3. Use o `index_github_actions.html` como a nova versão do `index.html` do portal.
4. Entre no portal como administrador e use **Conteúdo → Editar página inicial**.
5. Escolha as fotos, clique **Enviar foto** (isso só prepara a foto) e clique **Gerar pacote para o GitHub**.
6. No GitHub, abra `publicacoes`, clique **Add file → Upload files**, arraste o ZIP gerado e faça o commit na branch `main` (ou `master`, conforme o repositório).
7. O GitHub Actions extrai `central.json` e as imagens, remove o ZIP e grava a publicação no repositório.

## Resultado

Não é mais necessário colocar token/API do GitHub no navegador das administradoras. A atualização é feita pelo próprio GitHub quando o pacote é enviado ao repositório.

## Observação

O GitHub Actions não recebe o upload diretamente da página do portal. O passo intermediário é gerar um ZIP e enviar esse ZIP para o GitHub. Depois disso, a publicação é automática.
